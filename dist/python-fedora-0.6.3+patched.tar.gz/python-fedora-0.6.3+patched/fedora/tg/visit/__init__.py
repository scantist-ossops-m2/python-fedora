'''TurboGears visit manager to save visit in the Fedora Account System.'''

__all__ = ('jsonfasvisit',)
