'''
Templates to make adding templates for some common services easier.


.. moduleauthor:: Toshio Kuratomi <tkuratom@redhat.com>

.. versionadded:: 0.3.25
'''
