'''TurboGears identity modules that work with Fedora.'''

__all__ = ('jsonfasprovider',)
